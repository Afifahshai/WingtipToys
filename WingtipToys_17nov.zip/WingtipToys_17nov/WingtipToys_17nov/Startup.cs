﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(WingtipToys_17nov.Startup))]
namespace WingtipToys_17nov
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
