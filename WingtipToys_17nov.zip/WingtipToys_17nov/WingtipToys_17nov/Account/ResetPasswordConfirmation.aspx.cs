﻿using System.Web.UI;

namespace WingtipToys_17nov.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}