﻿using System.Data.Entity;

namespace WingtipToys_17nov.Models
{
    public class ProductContext : DbContext
    {
        public ProductContext() : base("WingtipToys_17nov")
        {
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }
}